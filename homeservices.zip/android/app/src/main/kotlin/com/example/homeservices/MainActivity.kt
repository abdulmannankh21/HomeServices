package com.example.homeservices

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
